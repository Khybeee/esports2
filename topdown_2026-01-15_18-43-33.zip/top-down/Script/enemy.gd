extends CharacterBody2D

var SPEED = 50 #the lower the value, the faste the speed
var player_chase = false
var player = null
var current_dir = "none"

func _physics_process(delta):
	if player_chase == true: #is equal to if player_chase:
		position+=(player.position - position)/SPEED
		#meaning, kung nasaan si player, doon siya pupunta, 
		#kaya 50 yung speed ni enemy kasi gagamit siya pang divide
		if player.position.x - position.x < 0:
			$EnemySprite.flip_h=true
		else: 
			$EnemySprite.flip_h=false

func _on_area_detector_body_entered(body: Node2D) -> void: #body dapat not area.
	#will happen if a body enters the area.
	player_chase = true
	player = body
	ORC_animation(1)

func _on_area_detector_body_exited(body: Node2D) -> void:
	player_chase = false
	player = null
	ORC_animation(0)

func ORC_animation(movement):
	var animated = $EnemySprite
	if current_dir == "right":
		animated.flip_h = false
	elif current_dir == "left":
		animated.flip_h = true
	
	if movement==1:
		animated.play("ORC_Walk")
	else:
		animated.play("ORC_Idle")
