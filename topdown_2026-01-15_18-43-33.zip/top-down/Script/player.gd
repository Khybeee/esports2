extends CharacterBody2D

var SPEED = 100
var current_dir="none"
#dir means direction

func _physics_process(delta):
	#under ng physics process ay diyan nagloloop
	player_movement(delta) #call

func player_movement(delta):
	if Input.is_action_pressed("ui_right"): #SLIDE TO RIGHT
		#means if nakapressed ka key like steady or matagal
		#if input.is_action_just_pressed if like single click or tap sa key.
		current_dir = "right"
		velocity.x = SPEED #x is left right
		velocity.y = 0 #y is up and down
		play_animation(1)
	elif Input.is_action_pressed("ui_left"): #SLIDE TO LEFT
		#elif is else if
		current_dir = "left"
		velocity.x = -SPEED
		velocity.y = 0
		play_animation(1)
	elif Input.is_action_pressed("ui_up"): #SLIDE UP
		#elif is else if
		velocity.x = 0
		velocity.y = -SPEED
		play_animation(1)
	elif Input.is_action_pressed("ui_down"): #SLIDE DOWN
		#elif is else if
		velocity.x = 0
		velocity.y = SPEED
		play_animation(1)
	else:									#not moving
		velocity.x = 0
		velocity.y = 0 
		play_animation(0)

func play_animation(movement):
	var animated = $AnimatedSprite2D
	if current_dir == "right":
		animated.flip_h = false
	elif current_dir == "left":
		animated.flip_h = true
	
	if movement==1:
		animated.play("SOLDIER_Walk")
	else:
		animated.play("SOLDIER_Idle")

	move_and_slide()
